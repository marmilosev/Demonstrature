/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ffos;

/**
 *
 * @author marija
 */
public class Organizacija {
    private int sifra;
    private String naziv;
    private int brojZaposlenika;

    public int getSifra() {
        return sifra;
    }

    public void setSifra(int sifra) {
        this.sifra = sifra;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public int getBrojZaposlenika() {
        return brojZaposlenika;
    }

    public void setBrojZaposlenika(int brojZaposlenika) {
        this.brojZaposlenika = brojZaposlenika;
    }
    
}
