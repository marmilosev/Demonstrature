/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ffos;

import java.util.Date;

/**
 *
 * @author marija
 */
public class Zaposlenik {
    
    private String ime;
    private String prezime;
    private Date datumZaposlenja;
    private float placa;
    private Organizacija organizacija;

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public Date getDatumZaposlenja() {
        return datumZaposlenja;
    }

    public void setDatumZaposlenja(Date datumZaposlenja) {
        this.datumZaposlenja = datumZaposlenja;
    }

    public float getPlaca() {
        return placa;
    }

    public void setPlaca(float placa) {
        this.placa = placa;
    }

    public ffos.Organizacija getOrganizacija() {
        return organizacija;
    }

    public void setOrganizacija(ffos.Organizacija organizacija) {
        this.organizacija = organizacija;
    }
    
}
